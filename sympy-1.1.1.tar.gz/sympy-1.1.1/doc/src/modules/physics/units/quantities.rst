===================
Physical quantities
===================

.. automodule:: sympy.physics.units.quantities

.. autoclass:: Quantity
   :members:

-----------------------------
Conversion between quantities
-----------------------------

.. automodule:: sympy.physics.units.util

.. autofunction:: convert_to
