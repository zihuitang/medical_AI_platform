=================
Quantum Mechanics
=================

.. topic:: Abstract

   Contains Docstrings of Physics-Quantum module

Quantum Functions
=================

.. toctree::
    :maxdepth: 3

    anticommutator.rst
    cg.rst
    commutator.rst
    constants.rst
    dagger.rst
    innerproduct.rst
    tensorproduct.rst

States and Operators
====================

.. toctree::
    :maxdepth: 3

    cartesian.rst
    hilbert.rst
    operator.rst
    operatorset.rst
    qapply.rst
    represent.rst
    spin.rst
    state.rst

Quantum Computation
===================

.. toctree::
    :maxdepth: 3

    circuitplot.rst
    gate.rst
    grover.rst
    qft.rst
    qubit.rst
    shor.rst

Analytic Solutions
==================


.. toctree::
    :maxdepth: 3

    piab.rst
