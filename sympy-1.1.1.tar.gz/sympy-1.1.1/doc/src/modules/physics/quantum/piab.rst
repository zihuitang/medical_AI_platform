=================
Particle in a Box
=================

.. automodule:: sympy.physics.quantum.piab
   :members:
