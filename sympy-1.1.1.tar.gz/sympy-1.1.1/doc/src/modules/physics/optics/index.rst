==============
Optics Module
==============

.. topic:: Abstract

    Contains docstrings of Physics-Optics module


.. toctree::
    :maxdepth: 3

    gaussopt.rst
    medium.rst
    utils.rst
    waves.rst
