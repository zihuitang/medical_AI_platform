======
Refine
======

.. automodule:: sympy.assumptions.refine
   :members:
