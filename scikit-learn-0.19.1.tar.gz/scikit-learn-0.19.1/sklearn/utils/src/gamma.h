#ifndef GAMMA_H
#define GAMMA_H

//double sklearn_gamma(double);
double sklearn_lgamma(double);

#endif

